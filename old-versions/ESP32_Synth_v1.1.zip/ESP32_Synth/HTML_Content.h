// HTML_content.h

#ifndef HTML_CONTENT_H
#define HTML_CONTENT_H

const char INDEX_HTML[] = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
    <title>APSIT_SYNTH Control</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { font-family: Arial, sans-serif; text-align: center; margin: 0; background-color: #222; color: #eee; }
        .container { max-width: 500px; margin: auto; padding: 15px; background-color: #333; box-shadow: 0 4px 8px rgba(0,0,0,0.5); }
        h1 { color: #88F; border-bottom: 2px solid #555; padding-bottom: 10px; margin-bottom: 20px; }
        h3 { color: #fff; margin-top: 25px; margin-bottom: 10px; }
        .control-group { margin-bottom: 20px; padding: 10px; border: 1px solid #444; border-radius: 8px; background-color: #444; text-align: left; }
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #ccc; }
        select, input[type="range"] { width: 100%; padding: 8px; margin-top: 5px; margin-bottom: 10px; border: none; border-radius: 4px; box-sizing: border-box; background-color: #555; color: #fff; }
        input[type="range"] { height: 25px; }
        
        /* Toggle Switch for OSC 2 */
        .switch { position: relative; display: inline-block; width: 40px; height: 20px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 34px; }
        .slider:before { position: absolute; content: ""; height: 14px; width: 14px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: #88F; }
        input:checked + .slider:before { transform: translateX(20px); }

        /* Custom Map Grid */
        .key-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 5px; margin-top: 15px; }
        .key-grid-item { padding: 5px; border: 1px solid #555; border-radius: 4px; background-color: #666; cursor: pointer; }
        .key-grid-item:hover { background-color: #88F; }
        .custom-note-selector { margin-top: 15px; }
        .status { margin-top: 20px; padding: 10px; border: 1px solid #666; border-radius: 5px; background-color: #555; text-align: center; }

    </style>
    <script>
        const NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
        let currentCustomKey = 0; // K1 by default

        function updateGainValue(osc, value) {
            document.getElementById('gain_value_' + osc).innerText = (value / 100).toFixed(2);
            sendGain(osc, value);
        }
        
        function sendGain(osc, gain) {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "/setgain?osc=" + osc + "&gain=" + gain, true);
            xhr.send();
        }

        function sendOsc2Toggle(checked) {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "/setgain?osc=2&enabled=" + (checked ? 1 : 0), true);
            xhr.send();
        }

        function sendWaveform(osc, wave) {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "/setosc?osc=" + osc + "&wave=" + wave, true);
            xhr.send();
        }

        function sendScale() {
            const root = document.getElementById('root_note').value;
            const type = document.getElementById('scale_type').value;
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "/setscale?root=" + root + "&type=" + type, true);
            xhr.send();
            
            // Show/hide custom map section
            document.getElementById('custom_map_section').style.display = (type == 4) ? 'block' : 'none';
        }
        
        function selectCustomKey(keyIndex) {
            currentCustomKey = keyIndex;
            // Highlight the selected key
            document.querySelectorAll('.key-grid-item').forEach(item => item.style.backgroundColor = '#666');
            document.getElementById('k_btn_' + keyIndex).style.backgroundColor = '#88F';
            
            document.getElementById('custom_key_label').innerText = 'K' + (keyIndex + 1);
        }

        function sendCustomNote() {
            const midiNote = document.getElementById('custom_note_select').value;
            const keyIndex = currentCustomKey;
            
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "/setcustomnote?key=" + keyIndex + "&note=" + midiNote, true);
            xhr.send();
            
            // Update the key label to reflect the new note
            const noteName = NOTE_NAMES[midiNote % 12];
            const octave = Math.floor(midiNote / 12) - 1; // C4 is 60, so 5th octave (index 4)
            document.getElementById('k_btn_' + keyIndex).innerText = 'K' + (keyIndex + 1) + ' (' + noteName + octave + ')';
        }

        // Auto-refresh function to update status
        setInterval(function() {
            fetch('/status')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('status-text').innerText = data.note;
                });
        }, 100); 

        // Initial setup for MIDI note dropdowns
        window.onload = function() {
            const rootNoteSelect = document.getElementById('root_note');
            const customNoteSelect = document.getElementById('custom_note_select');
            
            // Populate MIDI notes C3 (48) to C6 (84)
            for (let midi = 48; midi <= 84; midi++) {
                const noteName = NOTE_NAMES[midi % 12];
                const octave = Math.floor(midi / 12) - 1;

                const optionRoot = document.createElement('option');
                optionRoot.value = midi;
                optionRoot.innerText = noteName + octave;
                if (midi === 60) optionRoot.selected = true; // Default C4
                rootNoteSelect.appendChild(optionRoot);

                const optionCustom = document.createElement('option');
                optionCustom.value = midi;
                optionCustom.innerText = noteName + octave;
                customNoteSelect.appendChild(optionCustom);
            }
            sendScale(); // Initialize scale based on default selections
            updateGainValue(1, 100);
            document.getElementById('k_btn_0').style.backgroundColor = '#88F'; // Highlight K1
        };
    </script>
</head>
<body>
    <div class="container">
        <h1>APSIT Synth 🎹</h1>

        <div class="control-group">
            <h3>Scale Mapping</h3>
            <label for="root_note">Root Note:</label>
            <select id="root_note" onchange="sendScale()"></select>

            <label for="scale_type">Scale Type:</label>
            <select id="scale_type" onchange="sendScale()">
                <option value="0">Major</option>
                <option value="1">Minor</option>
                <option value="2">Pentatonic Major</option>
                <option value="3">Pentatonic Minor</option>
                <option value="4">Custom Map</option>
            </select>
        </div>

        <div class="control-group" id="custom_map_section" style="display:none;">
            <h3>Custom Key Mapper</h3>
            <label>Selected Key: <span id="custom_key_label">K1</span></label>
            
            <div class="custom-note-selector">
                <select id="custom_note_select"></select>
                <button onclick="sendCustomNote()">Set Note</button>
            </div>

            <div class="key-grid">
                <div class="key-grid-item" id="k_btn_0" onclick="selectCustomKey(0)">K1 (C4)</div>
                <div class="key-grid-item" id="k_btn_1" onclick="selectCustomKey(1)">K2</div>
                <div class="key-grid-item" id="k_btn_2" onclick="selectCustomKey(2)">K3</div>
                <div class="key-grid-item" id="k_btn_3" onclick="selectCustomKey(3)">K4</div>

                <div class="key-grid-item" id="k_btn_4" onclick="selectCustomKey(4)">K5</div>
                <div class="key-grid-item" id="k_btn_5" onclick="selectCustomKey(5)">K6</div>
                <div class="key-grid-item" id="k_btn_6" onclick="selectCustomKey(6)">K7</div>
                <div class="key-grid-item" id="k_btn_7" onclick="selectCustomKey(7)">K8</div>

                <div class="key-grid-item" id="k_btn_8" onclick="selectCustomKey(8)">K9</div>
                <div class="key-grid-item" id="k_btn_9" onclick="selectCustomKey(9)">K10</div>
                <div class="key-grid-item" id="k_btn_10" onclick="selectCustomKey(10)">K11</div>
                <div class="key-grid-item" id="k_btn_11" onclick="selectCustomKey(11)">K12</div>

                <div class="key-grid-item" id="k_btn_12" onclick="selectCustomKey(12)">K13</div>
                <div class="key-grid-item" id="k_btn_13" onclick="selectCustomKey(13)">K14</div>
                <div class="key-grid-item" id="k_btn_14" onclick="selectCustomKey(14)">K15</div>
                <div class="key-grid-item" id="k_btn_15" onclick="selectCustomKey(15)">K16</div>
            </div>
        </div>
        
        <div class="control-group">
            <h3>Oscillator 1</h3>
            <label for="osc1_wave">Waveform:</label>
            <select id="osc1_wave" onchange="sendWaveform(1, this.value)">
                <option value="0" selected>Sine</option>
                <option value="1">Square</option>
                <option value="2">Sawtooth</option>
                <option value="3">Triangle</option>
            </select>
            <label>Gain: <span id="gain_value_1">1.00</span></label>
            <input type="range" id="osc1_gain" min="0" max="100" value="100" oninput="updateGainValue(1, this.value)">
        </div>

        <div class="control-group">
            <h3>Oscillator 2</h3>
            <label for="osc2_wave">Waveform:</label>
            <select id="osc2_wave" onchange="sendWaveform(2, this.value)">
                <option value="0" selected>Sine</option>
                <option value="1">Square</option>
                <option value="2">Sawtooth</option>
                <option value="3">Triangle</option>
            </select>
            <label>Gain: <span id="gain_value_2">0.00</span></label>
            <input type="range" id="osc2_gain" min="0" max="100" value="0" oninput="updateGainValue(2, this.value)">
            
            <label>OSC 2 Enable: 
                <label class="switch">
                    <input type="checkbox" id="osc2_enable" onchange="sendOsc2Toggle(this.checked)">
                    <span class="slider"></span>
                </label>
            </label>
        </div>

        <div class="status">
            <strong>Last Key Pressed:</strong> <span id="status-text">None</span>
        </div>
    </div>
</body>
</html>
)rawliteral";

#endif