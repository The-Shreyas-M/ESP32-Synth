// UI.h

#ifndef UI_H
#define UI_H

#include <WiFi.h>
#include <WebServer.h>
#include "synth.h"
#include "HTML_content.h"

// WiFi credentials
const char* ssid = "APSIT_SYNTH";
const char* password = "12345678";

// Instantiate the web server
WebServer server(80);

// --- HANDLERS ---

void handleRoot() {
    server.send(200, "text/html", INDEX_HTML);
}

void handleSetOsc() {
    int oscNum = server.arg("osc").toInt(); 
    int waveType = server.arg("wave").toInt(); 

    if (waveType >= SINE && waveType <= TRIANGLE) {
        if (oscNum == 1) {
            synth.osc1Wave = (WaveType)waveType;
        } else if (oscNum == 2) {
            synth.osc2Wave = (WaveType)waveType;
        }
        server.send(200, "text/plain", "OK");
    } else {
        server.send(400, "text/plain", "Invalid Wave Type");
    }
}

void handleSetGain() {
    int oscNum = server.arg("osc").toInt();
    
    // Handle Gain (0 to 100)
    if (server.hasArg("gain")) {
        float gain = server.arg("gain").toFloat() / 100.0f;
        if (oscNum == 1) {
            synth.osc1Gain = gain;
        } else if (oscNum == 2) {
            synth.osc2Gain = gain;
        }
    }

    // Handle Enable/Disable (Only for OSC 2)
    if (oscNum == 2 && server.hasArg("enabled")) {
        synth.osc2Enabled = server.arg("enabled").toInt() == 1;
    }
    
    server.send(200, "text/plain", "OK");
}

void handleSetScale() {
    int rootMIDI = server.arg("root").toInt();
    int type = server.arg("type").toInt();
    
    synth.setScale(rootMIDI, type);
    
    server.send(200, "text/plain", "OK");
}

void handleSetCustomNote() {
    int keyIndex = server.arg("key").toInt();
    int midiNote = server.arg("note").toInt();
    
    synth.setCustomNote(keyIndex, midiNote);
    
    server.send(200, "text/plain", "OK");
}

void handleStatus() {
    String json = "{\"note\": \"";
    if (synth.lastPlayingKeyIndex != -1) {
        int midi = synth.currentScale[synth.lastPlayingKeyIndex];
        const char* noteName = NOTE_NAMES[midi % 12];
        int octave = (midi / 12) - 1;
        json += "K" + String(synth.lastPlayingKeyIndex + 1) + " (" + String(noteName) + String(octave) + ")";
    } else {
        json += "None";
    }
    json += "\"}";
    server.send(200, "application/json", json);
}

// --- SETUP & LOOP ---

void uiSetup() {
    WiFi.softAP(ssid, password);
    Serial.println("\n--- Starting UI Server ---");
    Serial.println("Hotspot: " + String(ssid));
    Serial.print("IP: ");
    Serial.println(WiFi.softAPIP());

    server.on("/", handleRoot);
    server.on("/setosc", handleSetOsc);
    server.on("/setgain", handleSetGain);
    server.on("/setscale", handleSetScale);
    server.on("/setcustomnote", handleSetCustomNote);
    server.on("/status", handleStatus);
    server.begin();
}

void uiLoop() {
    server.handleClient();
}

#endif