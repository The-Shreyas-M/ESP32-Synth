// control.cpp

#include "control.h"

void Control::begin() {
    // Setup Row Pins (OUTPUT)
    for (int i = 0; i < NUM_ROWS; i++) {
        pinMode(rowPins[i], OUTPUT);
        digitalWrite(rowPins[i], HIGH); // Rows start HIGH
    }
    
    // Setup Column Pins (INPUT_PULLUP)
    for (int i = 0; i < NUM_COLS; i++) {
        pinMode(colPins[i], INPUT_PULLUP);
    }
    
    // Minimal Serial output for init confirmation
    Serial.println("Control: Keypad Initialized.");
}

uint16_t Control::getPressedKeysBitmap() {
    uint16_t bitmap = 0;
    
    // --- SCAN THE 4x4 MATRIX AND BUILD BITMAP ---
    for (int row = 0; row < NUM_ROWS; row++) {
        
        // ACTIVATE the current Row: Drive it LOW
        digitalWrite(rowPins[row], LOW);
        delayMicroseconds(10); // Settle time for debouncing

        // READ all 4 Columns
        for (int col = 0; col < NUM_COLS; col++) {
            // Calculate the key index (0 to 15)
            int keyIndex = (row * NUM_COLS) + col;
            
            // LOW = Pressed 
            if (digitalRead(colPins[col]) == LOW) {
                // Set the corresponding bit in the bitmap: 
                // bit 0 for K1, bit 1 for K2, ..., bit 15 for K16
                bitmap |= (1 << keyIndex);
            }
        }

        // DEACTIVATE the current Row: Drive it back HIGH
        digitalWrite(rowPins[row], HIGH);
    }
    
    return bitmap;
}