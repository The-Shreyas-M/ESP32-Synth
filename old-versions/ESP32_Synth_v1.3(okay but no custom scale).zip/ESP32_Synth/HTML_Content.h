// HTML_content.h

#ifndef HTML_CONTENT_H
#define HTML_CONTENT_H

const char INDEX_HTML[] = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
    <title>APSIT_SYNTH Control</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { font-family: Arial, sans-serif; text-align: center; margin: 0; background-color: #222; color: #eee; }
        .container { max-width: 500px; margin: auto; padding: 15px; background-color: #333; box-shadow: 0 4px 8px rgba(0,0,0,0.5); }
        h1 { color: #88F; border-bottom: 2px solid #555; padding-bottom: 10px; margin-bottom: 20px; }
        h3 { color: #fff; margin-top: 25px; margin-bottom: 10px; }
        .control-group { margin-bottom: 20px; padding: 10px; border: 1px solid #444; border-radius: 8px; background-color: #444; text-align: left; }
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #ccc; }
        select, input[type="range"] { width: 100%; padding: 8px; margin-bottom: 10px; border: 1px solid #666; border-radius: 4px; box-sizing: border-box; background-color: #555; color: #eee; }
        select { height: 35px; }
        .switch { position: relative; display: inline-block; width: 60px; height: 34px; margin-left: 20px; vertical-align: middle; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 34px; }
        .slider:before { position: absolute; content: ""; height: 26px; width: 26px; left: 4px; bottom: 4px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: #2196F3; }
        input:checked + .slider:before { transform: translateX(26px); }
        .slider.round { border-radius: 34px; }
        .slider.round:before { border-radius: 50%; }
        #note_status { font-size: 1.2em; font-weight: bold; color: #0F0; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>ESP32 Polyphonic Synthesizer</h1>
        <div id="note_status">Current Note: None</div>

        <div class="control-group">
            <h3>ADSR Envelope (A/D/R in seconds, S is 0-1)</h3>
            <label>Attack Time (A): <span id="adsr_a_value">0.050s</span></label>
            <input type="range" id="adsr_a" min="0" max="300" value="50" oninput="updateADSRValue('a', this.value)" onmouseup="sendADSR()">
            
            <label>Decay Time (D): <span id="adsr_d_value">0.100s</span></label>
            <input type="range" id="adsr_d" min="0" max="300" value="100" oninput="updateADSRValue('d', this.value)" onmouseup="sendADSR()">
            
            <label>Sustain Level (S): <span id="adsr_s_value">0.50</span></label>
            <input type="range" id="adsr_s" min="0" max="100" value="50" oninput="updateADSRValue('s', this.value)" onmouseup="sendADSR()">
            
            <label>Release Time (R): <span id="adsr_r_value">0.500s</span></label>
            <input type="range" id="adsr_r" min="0" max="500" value="500" oninput="updateADSRValue('r', this.value)" onmouseup="sendADSR()">
        </div>
        
        <div class="control-group">
            <h3>Oscillator 1</h3>
            <label for="osc1_wave">Waveform:</label>
            <select id="osc1_wave" onchange="sendWaveform(1, this.value)">
                <option value="0" selected>Sine</option>
                <option value="1">Square</option>
                <option value="2">Sawtooth</option>
                <option value="3">Triangle</option>
            </select>
            <label>Gain: <span id="gain_value_1">1.00</span></label>
            <input type="range" id="osc1_gain" min="0" max="100" value="100" oninput="updateGainValue(1, this.value)" onmouseup="sendGain(1, this.value)">
        </div>

        <div class="control-group">
            <h3>Oscillator 2</h3>
            <label for="osc2_wave">Waveform:</label>
            <select id="osc2_wave" onchange="sendWaveform(2, this.value)">
                <option value="0" selected>Sine</option>
                <option value="1">Square</option>
                <option value="2">Sawtooth</option>
                <option value="3">Triangle</option>
            </select>
            <label>Gain: <span id="gain_value_2">0.00</span></label>
            <input type="range" id="osc2_gain" min="0" max="100" value="0" oninput="updateGainValue(2, this.value)" onmouseup="sendGain(2, this.value)">
            
            <label>OSC 2 Enable: 
                <label class="switch">
                    <input type="checkbox" id="osc2_enable" onchange="sendOsc2Toggle(this.checked)">
                    <span class="slider"></span>
                </label>
            </label>
        </div>
        
        <div class="control-group">
            <h3>Scale Mapping</h3>
            <label for="root_note">Root Note (C4 by default):</label>
            <input type="number" id="root_note" min="0" max="127" value="60" onchange="sendScaleUpdate()">
            <label for="scale_type">Scale Type:</label>
            <select id="scale_type" onchange="sendScaleUpdate()">
                <option value="0" selected>Major (Default)</option>
                <option value="1">Minor</option>
                <option value="2">Pentatonic Major</option>
                <option value="3">Pentatonic Minor</option>
                <option value="4">Custom/Free Map</option>
            </select>
        </div>
    </div>

    <script>
        const attackSlider = document.getElementById('adsr_a');
        const decaySlider = document.getElementById('adsr_d');
        const sustainSlider = document.getElementById('adsr_s');
        const releaseSlider = document.getElementById('adsr_r');
        
        const attackValue = document.getElementById('adsr_a_value');
        const decayValue = document.getElementById('adsr_d_value');
        const sustainValue = document.getElementById('adsr_s_value');
        const releaseValue = document.getElementById('adsr_r_value');

        // Function to update the ADSR display values
        function updateADSRValue(param, value) {
            let val = parseInt(value);
            let displayElement;
            let actualValue;

            if (param === 's') {
                // Sustain is a level: 0 to 1.0 (range 0 to 100)
                actualValue = val / 100.0;
                displayElement = sustainValue;
                displayElement.textContent = actualValue.toFixed(2);
            } else {
                // A/D/R are times in seconds (range 0 to 300/500 for 0 to 3.00s/5.00s)
                actualValue = val / 1000.0;
                displayElement = document.getElementById('adsr_' + param + '_value');
                displayElement.textContent = actualValue.toFixed(3) + 's';
            }
        }
        
        // Function to send ADSR values to the server
        function sendADSR() {
            const a = parseInt(attackSlider.value) / 1000.0;
            const d = parseInt(decaySlider.value) / 1000.0;
            const s = parseInt(sustainSlider.value) / 100.0;
            const r = parseInt(releaseSlider.value) / 1000.0;

            const xhr = new XMLHttpRequest();
            const url = '/setadsr?a=' + a.toFixed(3) + '&d=' + d.toFixed(3) + '&s=' + s.toFixed(2) + '&r=' + r.toFixed(3);
            xhr.open('GET', url, true);
            xhr.send();
        }


        // Existing functions...

        function sendWaveform(oscNum, waveType) {
            const xhr = new XMLHttpRequest();
            xhr.open("GET", "/setosc?osc=" + oscNum + "&wave=" + waveType, true);
            xhr.send();
        }

        function updateGainValue(oscNum, value) {
            let gain = parseInt(value) / 100.0;
            document.getElementById("gain_value_" + oscNum).textContent = gain.toFixed(2);
        }

        function sendGain(oscNum, value) {
            const xhr = new XMLHttpRequest();
            xhr.open("GET", "/setgain?osc=" + oscNum + "&gain=" + value, true);
            xhr.send();
        }

        function sendOsc2Toggle(checked) {
            const xhr = new XMLHttpRequest();
            const value = checked ? 1 : 0;
            xhr.open("GET", "/setgain?osc=2&enabled=" + value, true);
            xhr.send();
        }
        
        function sendScaleUpdate() {
            const root = document.getElementById('root_note').value;
            const type = document.getElementById('scale_type').value;
            
            const xhr = new XMLHttpRequest();
            xhr.open("GET", "/setscale?root=" + root + "&type=" + type, true);
            xhr.send();
        }

        // Status update loop
        function updateStatus() {
            fetch('/status')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('note_status').textContent = "Current Note: " + data.note;
                })
                .catch(error => {
                    console.error('Error fetching status:', error);
                    document.getElementById('note_status').textContent = "Current Note: Error";
                });
        }

        setInterval(updateStatus, 100); // Poll status every 100ms
        
        // Initialize gain display and ADSR display on load
        document.addEventListener('DOMContentLoaded', () => {
            updateGainValue(1, 100); // Default OSC1 gain
            updateGainValue(2, 0);   // Default OSC2 gain
            updateADSRValue('a', attackSlider.value);
            updateADSRValue('d', decaySlider.value);
            updateADSRValue('s', sustainSlider.value);
            updateADSRValue('r', releaseSlider.value);
        });

    </script>
</body>
</html>
)rawliteral";

#endif