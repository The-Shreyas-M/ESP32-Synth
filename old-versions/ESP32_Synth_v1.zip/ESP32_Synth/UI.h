// UI.h

#ifndef UI_H
#define UI_H

#include <WiFi.h>
#include <WebServer.h>
#include "synth.h"
#include "HTML_content.h"

// WiFi credentials (as requested)
const char* ssid = "APSIT_SYNTH";
const char* password = "12345678";

// Instantiate the web server
WebServer server(80);

void handleRoot() {
    server.send(200, "text/html", INDEX_HTML);
}

void handleSetOsc() {
    // Get oscillator number (1 or 2)
    int oscNum = server.arg("osc").toInt(); 
    // Get wave type (0-3)
    int waveType = server.arg("wave").toInt(); 

    if (waveType >= SINE && waveType <= TRIANGLE) {
        if (oscNum == 1) {
            synth.setOsc1Wave((WaveType)waveType);
            Serial.printf("UI: OSC 1 set to Wave %d\n", waveType);
        } else if (oscNum == 2) {
            synth.setOsc2Wave((WaveType)waveType);
            Serial.printf("UI: OSC 2 set to Wave %d\n", waveType);
            // Example: Make OSC 2 audible when changed from default 0.0
            synth.osc2.setAmplitude(0.5); 
        }
        server.send(200, "text/plain", "OK");
    } else {
        server.send(400, "text/plain", "Invalid Wave Type");
    }
}

void handleStatus() {
    // Send back the currently playing key index for the web UI update
    String json = "{\"note\": \"";
    if (synth.currentlyPlayingKeyIndex != -1) {
        json += "K" + String(synth.currentlyPlayingKeyIndex + 1);
    } else {
        json += "None";
    }
    json += "\"}";
    server.send(200, "application/json", json);
}

void uiSetup() {
    // WiFi AP and Server
    WiFi.softAP(ssid, password);
    Serial.println("\n--- Starting UI Server ---");
    Serial.println("Hotspot: " + String(ssid));
    Serial.print("IP: ");
    Serial.println(WiFi.softAPIP());

    server.on("/", handleRoot);
    server.on("/setosc", handleSetOsc);
    server.on("/status", handleStatus); // For AJAX updates
    server.begin();
}

void uiLoop() {
    server.handleClient();
}

#endif