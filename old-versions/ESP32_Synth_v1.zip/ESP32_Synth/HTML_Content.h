// HTML_content.h

#ifndef HTML_CONTENT_H
#define HTML_CONTENT_H

const char INDEX_HTML[] = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
    <title>APSIT_SYNTH Control</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { font-family: Arial, sans-serif; text-align: center; margin: 20px; background-color: #222; color: #eee; }
        .container { max-width: 400px; margin: auto; padding: 20px; border: 1px solid #444; border-radius: 10px; background-color: #333; }
        h2 { color: #88F; }
        .osc-control { margin-bottom: 20px; padding: 10px; border: 1px solid #555; border-radius: 5px; background-color: #444; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        select, button { width: 100%; padding: 10px; margin-top: 5px; margin-bottom: 10px; border: none; border-radius: 5px; font-size: 16px; box-sizing: border-box; }
        select { background-color: #555; color: #fff; }
        button { background-color: #007bff; color: white; cursor: pointer; }
        button:hover { background-color: #0056b3; }
        .status { margin-top: 20px; padding: 10px; border: 1px solid #666; border-radius: 5px; background-color: #555; }
    </style>
    <script>
        function sendWaveform(osc, wave) {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", "/setosc?osc=" + osc + "&wave=" + wave, true);
            xhr.send();
        }

        // Auto-refresh function to update status
        setInterval(function() {
            fetch('/status')
                .then(response => response.json())
                .then(data => {
                    document.getElementById('status-text').innerText = data.note;
                });
        }, 100); 
    </script>
</head>
<body>
    <div class="container">
        <h1>APSIT Synth 🎹</h1>

        <div class="osc-control">
            <h2>Oscillator 1</h2>
            <select id="osc1_wave" onchange="sendWaveform(1, this.value)">
                <option value="0">Sine</option>
                <option value="1">Square</option>
                <option value="2">Sawtooth</option>
                <option value="3">Triangle</option>
            </select>
        </div>

        <div class="osc-control">
            <h2>Oscillator 2</h2>
            <select id="osc2_wave" onchange="sendWaveform(2, this.value)">
                <option value="0">Sine</option>
                <option value="1">Square</option>
                <option value="2">Sawtooth</option>
                <option value="3">Triangle</option>
            </select>
        </div>

        <div class="status">
            <strong>Currently Playing Key:</strong> <span id="status-text">None</span>
        </div>
    </div>
</body>
</html>
)rawliteral";

#endif