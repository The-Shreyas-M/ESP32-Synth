// synth.cpp

#include "synth.h" 

// --- Global Initialization (Core 1 Access) ---
int16_t SINE_TABLE[SINE_TABLE_SIZE]; 

// Global Synth object definition (matches extern in synth.h)
Synth synth; 

// -------------------------------------------------------------------
// --- WAVEFORM GENERATORS (omitted for brevity, assume unchanged) ---
// -------------------------------------------------------------------

// [Oscillator::generateSine, generateSquare, generateSaw, generateTriangle]
int16_t Oscillator::generateSine(double phase) {
    return SINE_TABLE[(int)phase];
}

int16_t Oscillator::generateSquare(double phase) {
    if (phase < SINE_TABLE_SIZE / 2) {
        return 32767;
    } else {
        return -32767;
    }
}

int16_t Oscillator::generateSaw(double phase) {
    return (int16_t)((phase / SINE_TABLE_SIZE) * 2.0 * 32767.0 - 32767.0);
}

int16_t Oscillator::generateTriangle(double phase) {
    if (phase < SINE_TABLE_SIZE / 2) {
        return (int16_t)((phase / (SINE_TABLE_SIZE / 2.0)) * 2.0 * 32767.0 - 32767.0);
    } else {
        double downPhase = phase - SINE_TABLE_SIZE / 2.0;
        return (int16_t)(32767.0 - (downPhase / (SINE_TABLE_SIZE / 2.0)) * 2.0 * 32767.0);
    }
}

// -------------------------------------------------------------------
// --- OSCILLATOR CLASS IMPLEMENTATION (omitted for brevity, assume unchanged) ---
// -------------------------------------------------------------------

void Oscillator::setWaveform(WaveType type) { wave = type; }
void Oscillator::setFrequency(double freq) { 
    frequency = freq;
    phaseIncrement = frequency * SINE_TABLE_SIZE / I2S_SAMPLE_RATE;
}
void Oscillator::setAmplitude(double amp) { amplitude = amp; }

int16_t Oscillator::getNextSample() {
    WaveformFunc generator;
    switch (wave) {
        case SQUARE: generator = &Oscillator::generateSquare; break;
        case SAW: generator = &Oscillator::generateSaw; break;
        case TRIANGLE: generator = &Oscillator::generateTriangle; break;
        case SINE: 
        default: generator = &Oscillator::generateSine; break;
    }
    
    int16_t sample = generator(phaseAccumulator);
    int16_t finalSample = (int16_t)(sample * amplitude);

    phaseAccumulator += phaseIncrement;
    if (phaseAccumulator >= SINE_TABLE_SIZE) {
        phaseAccumulator -= SINE_TABLE_SIZE;
    }

    return finalSample;
}

// -------------------------------------------------------------------
// --- SYNTH CLASS IMPLEMENTATION ---
// -------------------------------------------------------------------

void Synth::begin() {
    // 1. Pre-calculate Sine Wave Lookup Table 
    for (int i = 0; i < SINE_TABLE_SIZE; i++) {
        SINE_TABLE[i] = (int16_t)(sin(i * 2.0 * PI / SINE_TABLE_SIZE) * 32767);
    }
    
    // 2. Install I2S Driver
    i2s_driver_install(I2S_PORT, &i2s_config, 0, NULL);
    i2s_set_pin(I2S_PORT, NULL);
    dac_output_enable(DAC_CHANNEL_1); 
    dac_output_enable(DAC_CHANNEL_2);
    
    // 3. Default Setup
    osc1.setAmplitude(1.0); 
    osc2.setAmplitude(0.0); 
    setScale(0); 

    Serial.println("Synth Engine: I2S & Oscillators ready.");
}

void Synth::setScale(int scaleRoot) {
    // TOTAL_KEYS is now available
    for (int i = 0; i < TOTAL_KEYS; i++) {
        currentScaleNotes[i] = (i + scaleRoot) % 12; 
    }
    Serial.printf("Synth: Scale set (chromatic starting at index %d)\n", scaleRoot % 12);
}

double Synth::getNoteFrequency(int keyIndex) {
    if (keyIndex < 0 || keyIndex >= TOTAL_KEYS) return 0.0;
    
    double baseFreq = NOTE_FREQS[currentScaleNotes[keyIndex]];
    
    // Keys 1-12 (index 0-11) are C4 octave, Keys 13-16 (index 12-15) are C5 octave
    int octaveShift = (keyIndex < 12) ? 0 : 1; 
    
    return baseFreq * pow(2, octaveShift);
}


void Synth::setKeyBitmap(uint16_t bitmap) {
    currentKeyBitmap = bitmap;
    
    // Monophonic Note Priority Logic (Highest key wins)
    int newPlayingKeyIndex = -1;
    for (int i = TOTAL_KEYS - 1; i >= 0; i--) {
        if (currentKeyBitmap & (1 << i)) {
            newPlayingKeyIndex = i;
            break; 
        }
    }
    
    if (newPlayingKeyIndex != currentlyPlayingKeyIndex) {
        currentlyPlayingKeyIndex = newPlayingKeyIndex;
        
        if (currentlyPlayingKeyIndex != -1) {
            // Note ON
            double freq = getNoteFrequency(currentlyPlayingKeyIndex);
            osc1.setFrequency(freq);
            osc2.setFrequency(freq); 
            Serial.printf("Note ON: K%d (%.2f Hz)\n", currentlyPlayingKeyIndex + 1, freq);
        } else {
            // Note OFF
            osc1.setFrequency(0.0);
            osc2.setFrequency(0.0);
            Serial.println("Note OFF");
        }
    }
}

void Synth::audioGeneratorLoop() {
    // This runs on Core 1

    while (true) {
        
        // FIX: Use the public getFrequency() method 
        bool noteIsPlaying = (osc1.getFrequency() > 0.0 || osc2.getFrequency() > 0.0);
        
        if (noteIsPlaying) {
            int samplesToGenerate = i2s_config.dma_buf_len;
            
            for (int i = 0; i < samplesToGenerate; i++) {
                
                int16_t sample1 = osc1.getNextSample();
                int16_t sample2 = osc2.getNextSample();
                
                int16_t mixedSample = (sample1 + sample2) / 2;

                uint8_t sample8Bit = (uint8_t)((mixedSample >> 8) + 128);
                int16_t final_sample = sample8Bit << 8;

                audioBuffer[i * 2] = final_sample;
                audioBuffer[i * 2 + 1] = final_sample;
            }

            size_t bytes_written;
            i2s_write(I2S_PORT, audioBuffer, sizeof(audioBuffer), &bytes_written, portMAX_DELAY);
        } else {
            size_t bytes_written;
            memset(audioBuffer, 0, sizeof(audioBuffer));
            i2s_write(I2S_PORT, audioBuffer, sizeof(audioBuffer), &bytes_written, portMAX_DELAY);
            vTaskDelay(1); 
        }
    }
}

void Synth::audioTask(void *parameter) {
    synth.audioGeneratorLoop(); 
}