// synth.h

#ifndef SYNTH_H
#define SYNTH_H

#include <Arduino.h>
#include "control.h" // Includes TOTAL_KEYS
#include "driver/i2s.h"
#include "driver/dac.h"
#include <math.h>

// --- I2S Configuration & Audio Constants ---
#define I2S_PORT I2S_NUM_0
#define I2S_SAMPLE_RATE 44100
#define SINE_TABLE_SIZE 512
#define DMA_BUF_LEN 64
#define AUDIO_BUFFER_SIZE (DMA_BUF_LEN * 2) 

// Global I2S Configuration 
const i2s_config_t i2s_config = {
  .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_DAC_BUILT_IN),
  .sample_rate = I2S_SAMPLE_RATE,
  .bits_per_sample = (i2s_bits_per_sample_t)16,
  .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
  .communication_format = (i2s_comm_format_t)I2S_COMM_FORMAT_STAND_MSB,
  .intr_alloc_flags = 0,
  .dma_buf_count = 8,
  .dma_buf_len = DMA_BUF_LEN, 
  .use_apll = false 
};

// Base C Major Frequencies (Hz) for one octave (C4 to B4)
// C, C#, D, D#, E, F, F#, G, G#, A, A#, B
const double A4_FREQ = 440.0;
const double NOTE_FREQS[12] = { 
    261.63, 277.18, 293.66, 311.13, 329.63, 349.23,
    369.99, 392.00, 415.30, 440.00, 466.16, 493.88
};

// Waveform Function Pointers
typedef int16_t (*WaveformFunc)(double phase);

// Enumeration for easy wave selection
enum WaveType {
    SINE,
    SQUARE,
    SAW,
    TRIANGLE,
    NUM_WAVES // Keep track of total wave types
};

// Global Array to hold the pre-calculated Sine Table (used by all oscillators)
extern int16_t SINE_TABLE[SINE_TABLE_SIZE];

// --- Core Oscillator Class ---
class Oscillator {
private:
    double phaseAccumulator = 0.0;
    double frequency = 0.0; // Private member
    double phaseIncrement = 0.0;
    double amplitude = 1.0;
    WaveType wave = SINE;
    
    // Waveform generator functions 
    static int16_t generateSine(double phase);
    static int16_t generateSquare(double phase);
    static int16_t generateSaw(double phase);
    static int16_t generateTriangle(double phase);
    
public:
    void setWaveform(WaveType type);
    void setFrequency(double freq);
    void setAmplitude(double amp);
    
    // ADDED PUBLIC GETTER to fix the private access error
    double getFrequency() const { return frequency; }

    int16_t getNextSample();
};

// --- Main Synth Class ---
class Synth {
public: 
    // Core state and I2S buffer
    int16_t audioBuffer[AUDIO_BUFFER_SIZE];
    uint16_t currentKeyBitmap = 0; 
    
    // Two Oscillator instances 
    Oscillator osc1;
    Oscillator osc2; 

    // Monophonic note tracking
    int currentlyPlayingKeyIndex = -1; 
    
    // Scale mapping
    int currentScaleNotes[TOTAL_KEYS]; // TOTAL_KEYS is now available
    
private: 
    double getNoteFrequency(int keyIndex);

public:
    void begin();
    void setKeyBitmap(uint16_t bitmap);
    void setOsc1Wave(WaveType type) { osc1.setWaveform(type); }
    void setOsc2Wave(WaveType type) { osc2.setWaveform(type); }
    
    void audioGeneratorLoop();
    void setScale(int scaleRoot);

    static void audioTask(void *parameter);
};

// Global Synth instance declaration (to be defined in synth.cpp)
extern Synth synth; 

#endif