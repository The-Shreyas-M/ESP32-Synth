// UI.h

#ifndef UI_H
#define UI_H

#include <WiFi.h>
#include <WebServer.h>
#include "synth.h"
#include "HTML_content.h"

// WiFi credentials
const char* ssid = "APSIT_SYNTH";
const char* password = "12345678";

// Instantiate the web server
WebServer server(80);

// --- HANDLERS ---

void handleRoot() {
    server.send(200, "text/html", INDEX_HTML);
}

void handleSetOsc() {
    int oscNum = server.arg("osc").toInt(); 
    int waveType = server.arg("wave").toInt(); 

    if (waveType >= SINE && waveType <= TRIANGLE) {
        if (oscNum == 1) {
            synth.osc1Wave = (WaveType)waveType;
        } else if (oscNum == 2) {
            synth.osc2Wave = (WaveType)waveType;
        }
        server.send(200, "text/plain", "OK");
    } else {
        server.send(400, "text/plain", "Invalid Wave Type");
    }
}

void handleSetGain() {
    int oscNum = server.arg("osc").toInt();
    
    // Handle Gain (0 to 100)
    if (server.hasArg("gain")) {
        double gain = server.arg("gain").toInt() / 100.0;
        
        if (oscNum == 1) {
            synth.osc1Gain = gain;
        } else if (oscNum == 2) {
            synth.osc2Gain = gain;
        }
        server.send(200, "text/plain", "OK");
    } else {
        server.send(400, "text/plain", "Missing Gain Parameter");
    }
}

void handleSetOsc2Toggle() {
    if (server.hasArg("enable")) {
        synth.osc2Enabled = server.arg("enable").toInt() == 1;
        server.send(200, "text/plain", "OK");
    } else {
        server.send(400, "text/plain", "Missing Enable Parameter");
    }
}

// NEW: Handler for ADSR settings
void handleSetADSR() {
    if (server.hasArg("attack")) {
        synth.attackMs = server.arg("attack").toDouble();
    } else if (server.hasArg("decay")) {
        synth.decayMs = server.arg("decay").toDouble();
    } else if (server.hasArg("sustain")) {
        // Sustain is 0-100 from UI, convert to 0.0-1.0
        synth.sustainLevel = server.arg("sustain").toDouble() / 100.0;
    } else if (server.hasArg("release")) {
        synth.releaseMs = server.arg("release").toDouble();
    }
    server.send(200, "text/plain", "OK");
}


void handleSetScale() {
    int rootMIDI = server.arg("root").toInt();
    int type = server.arg("type").toInt();
    
    synth.setScale(rootMIDI, type);
    
    server.send(200, "text/plain", "OK");
}

void handleSetCustomNote() {
    int keyIndex = server.arg("key").toInt();
    int midiNote = server.arg("note").toInt();
    
    synth.setCustomNote(keyIndex, midiNote);
    
    server.send(200, "text/plain", "OK");
}

void handleStatus() {
    String json = "{\"note\": \"";
    if (synth.lastPlayingKeyIndex != -1) {
        int midi = synth.currentScale[synth.lastPlayingKeyIndex];
        const char* noteName = NOTE_NAMES[midi % 12];
        int octave = (midi / 12) - 1;
        json += "K" + String(synth.lastPlayingKeyIndex + 1) + " (" + String(noteName) + String(octave) + ")";
    } else {
        json += "None";
    }
    json += "\"}";
    server.send(200, "application/json", json);
}

// --- SETUP & LOOP (UPDATED) ---

void uiSetup() {
    WiFi.softAP(ssid, password);
    Serial.println("\n--- Starting UI Server ---");
    Serial.print("Hotspot: ");
    Serial.println(ssid);
    Serial.print("IP Address: ");
    Serial.println(WiFi.softAPIP());

    server.on("/", HTTP_GET, handleRoot);
    server.on("/setOsc", HTTP_GET, handleSetOsc);
    server.on("/setGain", HTTP_GET, handleSetGain);
    server.on("/setOsc2", HTTP_GET, handleSetOsc2Toggle);
    server.on("/setScale", HTTP_GET, handleSetScale);
    server.on("/setCustomNote", HTTP_GET, handleSetCustomNote);
    server.on("/status", HTTP_GET, handleStatus);
    
    // NEW: ADSR Handler mapping
    server.on("/setADSR", HTTP_GET, handleSetADSR); 
    
    server.begin();
    Serial.println("Web Server Started.");
}

void uiLoop() {
    server.handleClient();
}

#endif // UI_H