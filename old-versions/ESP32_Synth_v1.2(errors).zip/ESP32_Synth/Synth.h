// synth.h

#ifndef SYNTH_H
#define SYNTH_H

#include <Arduino.h>
#include "control.h" 
#include "driver/i2s.h"
#include "driver/dac.h"
#include <math.h>

// Waveform Function Pointers
typedef int16_t (*WaveformFunc)(double phase);

// --- I2S Configuration & Audio Constants ---
#define I2S_PORT I2S_NUM_0
#define I2S_SAMPLE_RATE 44100.0 // Changed to float for calculations
#define SINE_TABLE_SIZE 512
#define DMA_BUF_LEN 64
#define AUDIO_BUFFER_SIZE (DMA_BUF_LEN * 2) 

// Global I2S Configuration (DECLARED HERE, DEFINED IN synth.cpp)
extern const i2s_config_t i2s_config;

// --- Note & Scale Constants (DECLARED HERE, DEFINED IN synth.cpp) ---
const int MIDI_C4 = 60;
extern const char* NOTE_NAMES[];

// Scale Step Intervals (in semitones) (DECLARED HERE, DEFINED IN synth.cpp)
extern const int SCALE_MAJOR[]; 
extern const int SCALE_MINOR[]; 
extern const int SCALE_PENT_MAJOR[]; 
extern const int SCALE_PENT_MINOR[]; 

// Waveform Enumeration
enum WaveType { SINE, SQUARE, SAW, TRIANGLE };

// --- ADSR Envelope Class (NEW) ---
class ADSR {
public:
    enum State { IDLE, ATTACK, DECAY, SUSTAIN, RELEASE };

private:
    State state = IDLE;
    double currentGain = 0.0;
    double sustainGain = 0.0;
    
    // Per-sample gain increments/decrements (calculated from ms in noteOn)
    double attackRate = 0.0;
    double decayRate = 0.0;
    double releaseRate = 0.0; 

public:
    void noteOn(double attackMs, double decayMs, double sustainLevel, double releaseMs);
    void noteOff();
    double getNextGain();
    State getState() const { return state; }
};

// --- Oscillator Class (UNMOVED) ---
class Oscillator {
private:
    double phase = 0.0;
    double phaseIncrement = 0.0;
    double frequency = 0.0;
    WaveformFunc waveFunc = nullptr;
    
public:
    void setFrequency(double freq);
    void setWaveform(WaveType type);
    double getFrequency() const { return frequency; }
    int16_t getNextSample();
};

// --- Voice Class (UPDATED) ---
class Voice {
public:
    Oscillator osc1;
    Oscillator osc2;
    ADSR adsr; // New ADSR envelope
    int keyIndex = -1; 
    
    void noteOn(double freq, WaveType wave1, WaveType wave2, double gain1, double gain2, 
                double attackMs, double decayMs, double sustainLevel, double releaseMs);
    void noteOff();
    int16_t getSample();
};


// --- Main Synth Class (UPDATED) ---
class Synth {
private: 
    int16_t audioBuffer[AUDIO_BUFFER_SIZE]; 
    uint16_t currentKeyBitmap = 0; 
    
    void calculateScale(int rootMIDI, int type);

public:
    // Global parameters controlled by Web UI
    WaveType osc1Wave = SINE;
    WaveType osc2Wave = SINE;
    double osc1Gain = 1.0;
    double osc2Gain = 0.0; 
    bool osc2Enabled = false;

    // NEW: Global ADSR Parameters (in milliseconds, Sustain is 0.0 to 1.0)
    double attackMs = 10.0; // 10ms
    double decayMs = 100.0; // 100ms
    double sustainLevel = 0.7; // 70%
    double releaseMs = 500.0; // 500ms

    // Polyphony: An array of 16 independent voices
    Voice voices[TOTAL_KEYS]; 

    // Scale mapping and UI state
    int currentScale[TOTAL_KEYS]; 
    int rootNoteMIDI = MIDI_C4; 
    int scaleType = 0; 
    
    // UI state for key reporting
    int lastPlayingKeyIndex = -1;
    
    void begin();
    static void audioTask(void * parameters); // Static wrapper for FreeRTOS
    void audioGeneratorLoop(); // Main audio generation loop
    
    // Control methods
    void setKeyBitmap(uint16_t newBitmap);
    void setScale(int rootMIDI, int type);
    void setCustomNote(int keyIndex, int midiNote);
};

// Global Synth Instance
extern Synth synth;

#endif // SYNTH_H