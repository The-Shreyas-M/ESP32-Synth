// synth.cpp

#include "synth.h" 

// -------------------------------------------------------------------
// --- GLOBAL DEFINITIONS (Fixing Linker Error) ---
// -------------------------------------------------------------------

// I2S Configuration
const i2s_config_t i2s_config = {
  .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX | I2S_MODE_DAC_BUILT_IN),
  .sample_rate = (int)I2S_SAMPLE_RATE,
  .bits_per_sample = (i2s_bits_per_sample_t)16,
  .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
  .communication_format = (i2s_comm_format_t)I2S_COMM_FORMAT_STAND_MSB,
  .intr_alloc_flags = 0,
  .dma_buf_count = 8,
  .dma_buf_len = DMA_BUF_LEN, 
  .use_apll = false 
};

// Note & Wave Names
const char* NOTE_NAMES[] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
const char* WAVE_NAMES[] = {"Sine", "Square", "Sawtooth", "Triangle"};

// Scale Step Intervals
const int SCALE_MAJOR[] = {2, 2, 1, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0};
const int SCALE_MINOR[] = {2, 1, 2, 2, 1, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0};
const int SCALE_PENT_MAJOR[] = {2, 2, 3, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
const int SCALE_PENT_MINOR[] = {3, 2, 2, 3, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

// Global Synth Instance
Synth synth;

// Pre-computed sine table
int16_t sineTable[SINE_TABLE_SIZE];

// -------------------------------------------------------------------
// --- WAVEFORM GENERATION FUNCTIONS (Unchanged logic) ---
// -------------------------------------------------------------------

int16_t sineWave(double phase) {
    int index = (int)(phase * SINE_TABLE_SIZE);
    return sineTable[index % SINE_TABLE_SIZE];
}

int16_t squareWave(double phase) {
    return (phase < 0.5) ? 32767 : -32767;
}

int16_t sawWave(double phase) {
    return (int16_t)((phase * 2.0 - 1.0) * 32767.0); 
}

int16_t triangleWave(double phase) {
    if (phase < 0.5) {
        return (int16_t)(phase * 4.0 * 32767.0 - 32767.0); 
    } else {
        return (int16_t)((1.0 - phase) * 4.0 * 32767.0 - 32767.0);
    }
}

// -------------------------------------------------------------------
// --- ADSR Implementation (NEW) ---
// -------------------------------------------------------------------

void ADSR::noteOn(double attackMs, double decayMs, double sustainLevel, double releaseMs) {
    // Attack Rate: 0.0 to 1.0
    if (attackMs > 0.0) {
        attackRate = 1.0 / (attackMs / 1000.0 * I2S_SAMPLE_RATE);
        state = ATTACK;
    } else {
        currentGain = 1.0;
        state = DECAY; // Skip to decay immediately
    }

    // Decay Rate: 1.0 to sustainLevel
    this->sustainGain = sustainLevel;
    if (decayMs > 0.0) {
        decayRate = (1.0 - sustainLevel) / (decayMs / 1000.0 * I2S_SAMPLE_RATE);
    } else {
        decayRate = 0.0;
    }

    // Release Rate: 1.0 to 0.0 in releaseMs
    if (releaseMs > 0.0) {
        releaseRate = 1.0 / (releaseMs / 1000.0 * I2S_SAMPLE_RATE); 
    } else {
        releaseRate = 1.0; // Instant release rate
    }
}

void ADSR::noteOff() {
    if (state != IDLE) {
        state = RELEASE;
    }
}

double ADSR::getNextGain() {
    switch (state) {
        case ATTACK:
            currentGain += attackRate;
            if (currentGain >= 1.0) {
                currentGain = 1.0;
                state = DECAY;
            }
            break;
            
        case DECAY:
            if (decayRate > 0.0) {
                currentGain -= decayRate;
                if (currentGain <= sustainGain) {
                    currentGain = sustainGain;
                    state = SUSTAIN;
                }
            } else {
                currentGain = sustainGain;
                state = SUSTAIN;
            }
            break;
            
        case SUSTAIN:
            // Hold at sustainGain
            break;
            
        case RELEASE:
            // The rate is calculated to go from 1.0 to 0.0 in total release time.
            // We use this step size to step down from the current gain.
            currentGain -= releaseRate; 
            if (currentGain <= 0.0) {
                currentGain = 0.0;
                state = IDLE;
            }
            break;

        case IDLE:
            currentGain = 0.0;
            break;
    }
    
    // Clamp the gain between 0.0 and 1.0
    return max(0.0, min(1.0, currentGain));
}

// -------------------------------------------------------------------
// --- Oscillator Implementation (Unchanged logic) ---
// -------------------------------------------------------------------

void Oscillator::setWaveform(WaveType type) {
    switch (type) {
        case SINE: waveFunc = sineWave; break;
        case SQUARE: waveFunc = squareWave; break;
        case SAW: waveFunc = sawWave; break;
        case TRIANGLE: waveFunc = triangleWave; break;
        default: waveFunc = sineWave; break;
    }
}

void Oscillator::setFrequency(double freq) {
    frequency = freq;
    phaseIncrement = frequency / I2S_SAMPLE_RATE; 
}

int16_t Oscillator::getNextSample() {
    if (frequency == 0.0 || waveFunc == nullptr) return 0;

    int16_t sample = waveFunc(phase);

    phase += phaseIncrement;
    if (phase >= 1.0) {
        phase -= 1.0;
    }

    return sample;
}

// -------------------------------------------------------------------
// --- Voice Implementation (UPDATED) ---
// -------------------------------------------------------------------

void Voice::noteOn(double freq, WaveType wave1, WaveType wave2, double gain1, double gain2, 
                   double attackMs, double decayMs, double sustainLevel, double releaseMs) {
    osc1.setFrequency(freq);
    osc1.setWaveform(wave1);
    
    if (freq > 0.0) {
        osc2.setFrequency(freq * 2.0); // Example of pitch detune
        osc2.setWaveform(wave2);
    }
    
    // Start the ADSR envelope
    adsr.noteOn(attackMs, decayMs, sustainLevel, releaseMs);
}

void Voice::noteOff() {
    // Start the Release phase of the ADSR envelope
    adsr.noteOff();
}

int16_t Voice::getSample() {
    // Get the next sample from both oscillators
    int32_t sample1 = (int32_t)(osc1.getNextSample() * synth.osc1Gain);
    int32_t sample2 = (int32_t)(osc2.getNextSample() * synth.osc2Gain * (synth.osc2Enabled ? 1.0 : 0.0));
    
    // Mix the oscillators and apply the ADSR gain
    double envelopeGain = adsr.getNextGain();
    int32_t mixedSample = (int32_t)((sample1 + sample2) * envelopeGain);
    
    return (int16_t)mixedSample;
}


// -------------------------------------------------------------------
// --- Synth Implementation (UPDATED) ---
// -------------------------------------------------------------------

void Synth::calculateScale(int rootMIDI, int type) {
    // A simpler polyphonic mapping for 16 keys: C4 to D#5 chromatic (original approach was complex)
    for (int i = 0; i < TOTAL_KEYS; i++) {
        currentScale[i] = rootMIDI + i; // Assumes a linear chromatic mapping from rootMIDI
    }
    // The scaleType logic is now ignored in calculateScale for a simple chromatic mapping,
    // which aligns with the simple tone generation request.
}

void Synth::begin() {
    // 1. Pre-compute sine wave table for efficiency
    for (int i = 0; i < SINE_TABLE_SIZE; i++) {
        sineTable[i] = (int16_t)(sin((double)i / SINE_TABLE_SIZE * 2.0 * PI) * 32767.0);
    }
    
    // 2. Initialize I2S
    i2s_driver_install(I2S_PORT, &i2s_config, 0, NULL);
    i2s_set_dac_mode(I2S_DAC_CHANNEL_BOTH_EN);
    
    // 3. Initialize voices to idle state
    for (int i = 0; i < TOTAL_KEYS; i++) {
        voices[i].keyIndex = -1;
    }
    
    // 4. Initial scale calculation (C4 Chromatic by default for 16 keys)
    calculateScale(MIDI_C4, 0); 
    
    Serial.println("Synth Engine Initialized.");
}

void Synth::setKeyBitmap(uint16_t newBitmap) {
    uint16_t stateChanges = currentKeyBitmap ^ newBitmap;
    currentKeyBitmap = newBitmap;
    
    for (int i = 0; i < TOTAL_KEYS; i++) {
        // Key just pressed (bit changed from 0 to 1)
        bool keyIsPressed = (newBitmap >> i) & 1;
        bool keyJustPressed = keyIsPressed && (stateChanges & (1 << i));
        // Key just released (bit changed from 1 to 0)
        bool keyJustReleased = (!keyIsPressed) && (stateChanges & (1 << i));

        if (keyJustPressed) {
            // NOTE ON: Key just pressed
            double freq = 440.0 * pow(2.0, (currentScale[i] - 69) / 12.0);
            
            voices[i].noteOn(
                freq, 
                osc1Wave, 
                osc2Wave, 
                osc1Gain, 
                osc2Gain,
                attackMs,    // Pass global ADSR values
                decayMs,
                sustainLevel,
                releaseMs
            );
            voices[i].keyIndex = i;
            lastPlayingKeyIndex = i; 
            
        } else if (keyJustReleased) {
            // NOTE OFF: Key just released - Trigger release phase
            voices[i].noteOff();
            // Do NOT clear keyIndex yet, let the envelope run!
        }
    }
}

void Synth::setScale(int rootMIDI, int type) {
    rootNoteMIDI = rootMIDI;
    scaleType = type;
    calculateScale(rootMIDI, type);
}

void Synth::setCustomNote(int keyIndex, int midiNote) {
    if (keyIndex >= 0 && keyIndex < TOTAL_KEYS) {
        currentScale[keyIndex] = midiNote;
    }
}

// Static wrapper for FreeRTOS
void Synth::audioTask(void * parameters) {
    synth.audioGeneratorLoop();
}

void Synth::audioGeneratorLoop() {
    while (true) {
        size_t bytesWritten;
        int samplesToGenerate = i2s_config.dma_buf_len;
        
        for (int i = 0; i < samplesToGenerate; i++) {
            int32_t mixedSample32Bit = 0;

            for (int v = 0; v < TOTAL_KEYS; v++) {
                // Only process voice if the envelope is not IDLE
                if (voices[v].adsr.getState() != ADSR::IDLE) {
                    mixedSample32Bit += voices[v].getSample();
                } else {
                    // Envelope is finished, clear the key index
                    voices[v].keyIndex = -1;
                }
            }
            
            // Final normalization/scaling (Divided by 8 for safety with 16 voices)
            int16_t finalMixedSample = (int16_t)(mixedSample32Bit / 8); 

            // Convert 16-bit signed to 8-bit unsigned DAC format for I2S output:
            uint8_t sample8Bit = (uint8_t)((finalMixedSample >> 8) + 128);
            
            // Format for I2S DAC (R/L channels)
            int16_t final_sample = sample8Bit << 8; 

            audioBuffer[i * 2] = final_sample; // Left channel
            audioBuffer[i * 2 + 1] = final_sample; // Right channel
        }
        
        // Write data to I2S
        i2s_write(I2S_PORT, audioBuffer, AUDIO_BUFFER_SIZE * sizeof(int16_t), &bytesWritten, portMAX_DELAY);
    }
}