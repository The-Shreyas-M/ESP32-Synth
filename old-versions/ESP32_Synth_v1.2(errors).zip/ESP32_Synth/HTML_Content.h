// HTML_content.h

#ifndef HTML_CONTENT_H
#define HTML_CONTENT_H

const char INDEX_HTML[] = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
    <title>APSIT_SYNTH Control</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body { font-family: Arial, sans-serif; text-align: center; margin: 0; background-color: #222; color: #eee; }
        .container { max-width: 500px; margin: auto; padding: 15px; background-color: #333; box-shadow: 0 4px 8px rgba(0,0,0,0.5); }
        h1 { color: #88F; border-bottom: 2px solid #555; padding-bottom: 10px; margin-bottom: 20px; }
        h3 { color: #fff; margin-top: 25px; margin-bottom: 10px; }
        .control-group { margin-bottom: 20px; padding: 10px; border: 1px solid #444; border-radius: 8px; background-color: #444; text-align: left; }
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #ccc; }
        select, input[type="range"] { width: 100%; height: 25px; background: #555; border-radius: 5px; outline: none; transition: opacity .2s; }
        
        /* Toggle Switch for OSC2 Enable */
        .switch { position: relative; display: inline-block; width: 40px; height: 24px; vertical-align: middle; margin-left: 10px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; -webkit-transition: .4s; transition: .4s; border-radius: 24px; }
        .slider:before { position: absolute; content: ""; height: 16px; width: 16px; left: 4px; bottom: 4px; background-color: white; -webkit-transition: .4s; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: #2196F3; }
        input:checked + .slider:before { -webkit-transform: translateX(16px); -ms-transform: translateX(16px); transform: translateX(16px); }
        
        .status-bar { padding: 10px; background-color: #1a1a1a; border-radius: 8px; margin-top: 15px; font-size: 1.1em; color: #0F0; }
        
        /* ADSR Layout */
        .adsr-label { display: inline-block; width: 20%; text-align: center; font-size: 0.8em; }
        .adsr-group { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .adsr-control { flex: 1; padding: 0 5px; }
        
    </style>
    <script>
        function sendCommand(path) {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', path, true);
            xhr.send();
        }

        function updateGainValue(oscNum, value) {
            var gain = (value / 100.0).toFixed(2);
            document.getElementById('gain_value_' + oscNum).innerHTML = gain;
            sendCommand('/setGain?osc=' + oscNum + '&gain=' + value);
        }
        
        function updateADSRValue(param, value) {
            // Update the display value
            document.getElementById(param + '_value').innerHTML = (param === 'sustain') ? (value / 100.0).toFixed(2) : (value + 'ms');
            // Send command to the ESP32
            sendCommand('/setADSR?' + param + '=' + value);
        }

        function sendWaveform(oscNum, value) {
            sendCommand('/setOsc?osc=' + oscNum + '&wave=' + value);
        }
        
        function sendOsc2Toggle(checked) {
            sendCommand('/setOsc2?enable=' + (checked ? '1' : '0'));
        }

        function sendScale() {
            var root = document.getElementById('root_note').value;
            var type = document.getElementById('scale_type').value;
            sendCommand('/setScale?root=' + root + '&type=' + type);
        }

        function updateStatus() {
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var response = JSON.parse(xhr.responseText);
                    document.getElementById('note_status').innerHTML = response.note;
                }
            };
            xhr.open('GET', '/status', true);
            xhr.send();
        }

        window.onload = function() {
            setInterval(updateStatus, 100); // Update key status every 100ms
        };
        
    </script>
</head>
<body>
    <div class="container">
        <h1>ESP32 PolySynth Control</h1>

        <div class="status-bar">
            Note Playing: <span id="note_status">None</span>
        </div>

        <div class="control-group">
            <h3>ADSR Envelope (ms / Level)</h3>
            <div class="adsr-group">
                <div class="adsr-control">
                    <label class="adsr-label">Attack: <span id="attack_value">10ms</span></label>
                    <input type="range" id="attack_ms" min="1" max="1000" value="10" oninput="updateADSRValue('attack', this.value)">
                </div>
                <div class="adsr-control">
                    <label class="adsr-label">Decay: <span id="decay_value">100ms</span></label>
                    <input type="range" id="decay_ms" min="1" max="2000" value="100" oninput="updateADSRValue('decay', this.value)">
                </div>
            </div>
            <div class="adsr-group">
                <div class="adsr-control">
                    <label class="adsr-label">Sustain: <span id="sustain_value">0.70</span></label>
                    <input type="range" id="sustain_level" min="0" max="100" value="70" oninput="updateADSRValue('sustain', this.value)">
                </div>
                <div class="adsr-control">
                    <label class="adsr-label">Release: <span id="release_value">500ms</span></label>
                    <input type="range" id="release_ms" min="1" max="5000" value="500" oninput="updateADSRValue('release', this.value)">
                </div>
            </div>
        </div>
        <div class="control-group">
            <h3>Oscillator 1</h3>
            <label for="osc1_wave">Waveform:</label>
            <select id="osc1_wave" onchange="sendWaveform(1, this.value)">
                <option value="0" selected>Sine</option>
                <option value="1">Square</option>
                <option value="2">Sawtooth</option>
                <option value="3">Triangle</option>
            </select>
            <label>Gain: <span id="gain_value_1">1.00</span></label>
            <input type="range" id="osc1_gain" min="0" max="100" value="100" oninput="updateGainValue(1, this.value)">
        </div>

        <div class="control-group">
            <h3>Oscillator 2</h3>
            <label for="osc2_wave">Waveform:</label>
            <select id="osc2_wave" onchange="sendWaveform(2, this.value)">
                <option value="0" selected>Sine</option>
                <option value="1">Square</option>
                <option value="2">Sawtooth</option>
                <option value="3">Triangle</option>
            </select>
            <label>Gain: <span id="gain_value_2">0.00</span></label>
            <input type="range" id="osc2_gain" min="0" max="100" value="0" oninput="updateGainValue(2, this.value)">
            
            <label>OSC 2 Enable: 
                <label class="switch">
                    <input type="checkbox" id="osc2_enable" onchange="sendOsc2Toggle(this.checked)">
                    <span class="slider"></span>
                </label>
            </label>
        </div>

        <div class="control-group">
            <h3>Key Mapping</h3>
            <div style="display: flex; justify-content: space-between;">
                <div style="flex: 1; margin-right: 10px;">
                    <label for="root_note">Root Note:</label>
                    <select id="root_note">
                        <option value="60">C4</option>
                        <option value="61">C#4</option>
                        <option value="62">D4</option>
                        <option value="63">D#4</option>
                        <option value="64">E4</option>
                        <option value="65">F4</option>
                        <option value="66">F#4</option>
                        <option value="67">G4</option>
                        <option value="68">G#4</option>
                        <option value="69">A4</option>
                        <option value="70">A#4</option>
                        <option value="71">B4</option>
                    </select>
                </div>
                <div style="flex: 1; margin-left: 10px;">
                    <label for="scale_type">Scale Type (TBD):</label>
                    <select id="scale_type">
                        <option value="0" selected>Major (Chromatic)</option>
                        <option value="1">Minor (Chromatic)</option>
                        <option value="2">Pent. Major (Chromatic)</option>
                        <option value="3">Pent. Minor (Chromatic)</option>
                    </select>
                </div>
            </div>
            <button onclick="sendScale()" style="width: 100%; padding: 10px; margin-top: 10px; background-color: #555; color: white; border: none; border-radius: 4px; cursor: pointer;">Set Scale</button>
        </div>
        
    </div>
</body>
</html>
)rawliteral";

#endif // HTML_CONTENT_H